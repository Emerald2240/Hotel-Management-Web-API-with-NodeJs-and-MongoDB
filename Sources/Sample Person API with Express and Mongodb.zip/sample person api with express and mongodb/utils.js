const addNumbers = (a, b) => {
    return a + b;
};

const divideNumbers = (a, b) => {
    return a / b;
};

const multiplyNumbers = (a, b) => {
    return a * b;
};

const minusNumbers = (a, b) => {
    return a - b;
};

module.exports = { 
    addNumbers,
    divideNumbers,
    multiplyNumbers,
    minusNumbers,
};